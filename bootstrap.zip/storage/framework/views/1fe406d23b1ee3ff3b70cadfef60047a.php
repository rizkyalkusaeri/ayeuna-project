<?php $__env->startSection('title'); ?>
    Beranda Admin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
    <h4>Selamat Datang <b><?php echo e(Auth::user()->name); ?></b></h4>
    <h4>Anda tercatat sebagai admin di <b>
            Sistem</b></h4>
    <br>

    <h3 class="font-bold">Silahkan import data user disini</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="file" class="form-label">File excel</label>
            <input class="form-control" type="file" id="file" name="file" required>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Import</button>
    </form>

    <br>
    <h3 class="font-bold">Data Relawan</h3>
    <div class="container">
        <div class="table-responsive-sm" style="width: 95%">
            <table id="table" class="table table-striped table-bordered table-hover table-sm">
                <thead>
                    <th class="text-center">NIK</th>
                    <th class="text-center">Nama</th>
                    <th class="text-center">TPS</th>
                    <th class="text-center">Kelurahan</th>
                    <th class="text-center">Kecamatan</th>
                </thead>
                <tbody>
                    <?php if(count($data) > 0): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dt->email); ?></td>
                                <td><?php echo e($dt->name); ?></td>
                                <td><?php echo e($dt->tps); ?></td>
                                <td><?php echo e($dt->kelurahan); ?></td>
                                <td><?php echo e($dt->kecamatan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">Tidak ada data tersedia</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('costum-script'); ?>
    <script>
        $('#table').DataTable();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\freelance\ayeuna-project\resources\views/home/admin.blade.php ENDPATH**/ ?>