<?php $__env->startSection('title'); ?>
    Beranda
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
    <h4>Selamat Datang <b><?php echo e(Auth::user()->name); ?></b></h4>
    <?php if(Auth::user()->role == 'admin'): ?>
        <h4>Anda tercatat sebagai admin di <b>
                Sistem</b></h4>
        <br>

        <h3 class="font-bold">Silahkan import data user disini</h3>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="file" class="form-label">File excel</label>
                <input class="form-control" type="file" id="file" name="file" required>
            </div>
            <br>
            <button type="submit" class="btn btn-primary">Import</button>
        </form>
    <?php else: ?>
        <h4>Anda tercatat sebagai relawan di <b>TPS : <?php echo e(Auth::user()->tps); ?>, <?php echo e(Auth::user()->kelurahan); ?>,
                <?php echo e(Auth::user()->kecamatan); ?></b></h4>
        <br>

        <h3 class="font-bold">Panduan Pengisian Rekapitulasi</h3>
        <ul class="list-group">
            <li class="list-group-item">Langkah 1: Anda harus melakukan absen di pagi hari dengan mengisi link berikut <a
                    href="<?php echo e(route('go_absen')); ?>" target="__blank"><b>Klik disini</b></a> </li>
            <li class="list-group-item">Langkah 2: Anda harus mengisi Pengisian Hasil Suara pada link berikut <a
                    href="<?php echo e(route('go_isi')); ?>" target="__blank"><b>Klik disini</b></a></li>
            <li class="list-group-item">Langkah 3: Selesai</li>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\freelance\ayeuna-project\resources\views/home/index.blade.php ENDPATH**/ ?>